# Order Slip Android (H.B Store Order)

WebView wrapper around `app/src/main/assets/index.html` (hborder.html) with in-app auto update.

## How updating works
1. Run the "Release APK" workflow. Version code = GitHub run number, tag = `v<run number>`, release title `OrderSlip v3.0.<run number>`.
2. On launch the app reads the latest release tag; if the number is higher than the installed versionCode it offers the update.
3. The app deletes old APKs, downloads `OrderSlip.apk`, checks version + signing key, then opens the installer (only while the app is on screen).

## Keep in mind
- Never delete or replace `release-key.jks` in the repo. A different key = Android refuses updates.
- Keep only ONE `OrderSlipAndroid*.zip` in the repo (the workflow uses the highest name).

## Firebase login

This build keeps the original Order Slip project and adds Firebase authentication inside the WebView. See `FIREBASE_SETUP.md` and `FIREBASE_FIRESTORE_RULES.txt`.

Important: enable **Anonymous** sign-in for Shop mode and **Email/Password** for Admin/Storekeeper mode.


Storekeeper dashboard update: three separate shop cards (H.B MALL, H.B KHARTHIYATH, H.B SOUQ), per-shop pending orders, checklist view, cloud save, and Complete order status.
