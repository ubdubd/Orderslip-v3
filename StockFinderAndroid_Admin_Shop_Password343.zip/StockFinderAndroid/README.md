# Stock Finder Android App

WebView wrapper around the Happy Baby Store Stock Finder HTML app.

- PDF export buttons share directly to WhatsApp via a native bridge (ShareBridge.java).
- In-app auto-updater checks the latest GitHub Release of this repo.
- Built via GitHub Actions (see .github/workflows/build.yml in the repo root).
