# Happy Baby Store cloud setup

The app is wired to Firebase project `hb-order-slip`.

## 1. Firebase Authentication
In Firebase Console → Authentication → Sign-in method:
- Enable **Anonymous** (for normal Shop entry).
- Enable **Email/Password** (for Admin and Storekeeper).

Create the Admin and Storekeeper accounts in Authentication. Then create matching Firestore documents:

`users/<AUTH_UID>`
```json
{
  "role": "admin",
  "name": "Admin"
}
```

and

`users/<AUTH_UID>`
```json
{
  "role": "storekeeper",
  "name": "Storekeeper"
}
```

Use the real Firebase Auth UID for each document.

## 2. Firestore
Create a Firestore database and publish `FIREBASE_FIRESTORE_RULES.txt` as the rules.

The app uses:
- `products/current` — latest stock published by Admin.
- `users/<uid>` — role/shop identity.
- `orders/<orderId>` — shop orders.
- `shops/<shopId>` — optional shop master data.

## 3. Workflow
- **Admin:** password login → upload/edit stock → changes are published to `products/current`.
- **Storekeeper:** password login → sees pending shop orders inside the app.
- **Shop:** normal entry with shop name/code → receives live admin stock → sending the cart creates an in-app Firestore order. The Shop order button no longer opens WhatsApp.
- Admin/Storekeeper can Accept, Complete or Cancel an order.

The Android project already contains the Firebase project settings needed by the web app. Internet access is required for live sync.


## Default Admin Password
The requested initial Admin password is **343**. Firebase Authentication still requires the Admin user to be created once in Firebase Console. Create an Email/Password user for the Admin account and set its initial password to `343`; then create the matching `users/{uid}` Firestore document with `role: "admin"`. After login, the app now has a **🔐 Password** button where Admin can change the password inside the app.

The same in-app password change is available to Storekeeper after that account is created.
